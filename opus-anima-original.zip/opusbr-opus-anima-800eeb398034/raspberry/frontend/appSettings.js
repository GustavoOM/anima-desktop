const appSettings = {
    simulateSocketIo: false,

    monitorApiBaseUrl: 'http://localhost:5000',
    monitorSocketBaseUrl: 'http://localhost:5000',

    // monitorApiBaseUrl: 'http://192.168.0.16:5000',
    // monitorSocketBaseUrl: 'http://192.168.0.16:5000',

    // monitorApiBaseUrl: 'http://350fd1479930.ngrok.io',
    // monitorSocketBaseUrl: 'http://350fd1479930.ngrok.io'
}
