source ~/Documents/opus-anima/raspberry/animaenv/bin/activate
python3 ~/Documents/opus-anima/raspberry/api/auto_calib.py
