import serial
import json
import os
from time import sleep
from random import random

parameters = ["timestamp",
			  "pressaoEntradaArP1",
			  "pressaoEntradaArOxP2",
			  "pressaoEntradaArP3",
			  "pressaoEntradaOxP4",
			  "pressaoMisturaP5",
			  "pressaoExalacaoP6",
			  "fluxoArF1",
			  "fluxoOxF2",
			  "fluxoMisturaF3",
			  "fluxoExalacaoF4"]


def serial_send():
    os.system("python3 write_serial.py")


def main():
    port = serial.Serial("/dev/serial0", baudrate=9600, timeout=3.0)
    for i in range(20):
        sleep(1)
        data = {key:random() for key in parameters[1:]}
        str_data = str(random())
        for value in data.values():
            str_data += "," + str(value)
        str_data += ";"
        message = bytes(str_data, "ascii")
        print(message)
        port.write(message)


if __name__ == '__main__':
    main()
