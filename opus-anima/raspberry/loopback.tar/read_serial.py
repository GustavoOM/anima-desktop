import requests 
import serial
import json

parameters = ["timestamp",
			  "pressaoEntradaArP1",
			  "pressaoEntradaArOxP2",
			  "pressaoEntradaArP3",
			  "pressaoEntradaOxP4",
			  "pressaoMisturaP5",
			  "pressaoExalacaoP6",
			  "fluxoArF1",
			  "fluxoOxF2",
			  "fluxoMisturaF3",
			  "fluxoExalacaoF4"]


def read_stream(port):
    rv = ""
    while True:
        ch = port.read().decode("ascii")
        if ch==';' or ch=='':
            return rv
        rv += ch


def main():
    port = serial.Serial("/dev/serial0", baudrate=9600, timeout=3.0)

    while True:
        data = read_stream(port)
        data = data.split(',')
        if len(parameters) == len(data):
            message = {}
            for i, key in enumerate(parameters):
                message[key] = float(data[i])	
            print(message)


if __name__ == '__main__':
    print("Listening...")
    main()
